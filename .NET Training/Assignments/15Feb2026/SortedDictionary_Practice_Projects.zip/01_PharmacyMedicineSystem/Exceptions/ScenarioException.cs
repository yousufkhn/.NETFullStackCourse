namespace Exceptions
{
    public class ScenarioException : CustomBaseException
    {
        public ScenarioException(string message) : base(message) { }
    }
}
