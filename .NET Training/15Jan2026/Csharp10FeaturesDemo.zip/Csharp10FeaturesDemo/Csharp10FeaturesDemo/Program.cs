﻿//// See https://aka.ms/new-console-template for more information
//global using System;
//global using System.Collections.Generic;
//global using Pankaj.CG;
//global using System.Linq;
//global using System.IO;
//using Csharp10FeaturesDemo;

//Console.WriteLine("Hello, World!");
//Menu();
//StructImprovementDemo.StructMain();



//static void Menu()
//{
//    Console.WriteLine("1. Global usings");
//    Console.WriteLine("2 Null parameter checking");
//    Console.WriteLine("3. File - scoped namespaces");
//   Console.WriteLine("4. Constant interpolated strings");
//    Console.WriteLine("5. Attribute support generics");
//    Console.WriteLine("6. Record structs");
//    Console.WriteLine("7. Extended property patterns");
//    Console.WriteLine("8. Structure type improvements");
//    Console.WriteLine("9. Record types can seal ToString");
//    Console.WriteLine("10. Lambda improvements");

//}