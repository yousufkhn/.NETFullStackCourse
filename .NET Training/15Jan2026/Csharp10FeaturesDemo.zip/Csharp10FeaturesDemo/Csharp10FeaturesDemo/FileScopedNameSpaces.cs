﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//n C# 10, you can follow the new way of a namespace declaration as shown below
namespace Csharp10FeaturesDemo;

internal class FileScopedNameSpaces
{
}
