﻿

namespace Csharp10FeaturesDemo
{
    internal class GlobalUsingDemo
    {
        public static void Show()
        {
            List<string> list = new List<string>();
            Console.WriteLine();
        }
    }
}
