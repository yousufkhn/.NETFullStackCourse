﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pankaj.CG;

namespace Csharp10FeaturesDemo
{
    internal class Class1
    {
       
    }
}
