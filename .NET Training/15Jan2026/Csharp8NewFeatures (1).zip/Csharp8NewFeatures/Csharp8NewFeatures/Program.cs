﻿//// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
////The main advantage of @ symbol is to tell the string constructor to ignore escape characters 
////and line breaks.@ is known as a verbatim identifier
//Console.WriteLine(@"1.Readonly Struct Members
//2. Default Interface Methods
//3. Pattern Matching Enhancements
//4. Using Declarations
//5. Static local functions
//6. Disposable ref structs
//7. Nullable reference types
//8. Asynchronous streams
//9. Asynchronous disposable
//10. Indices and ranges
//11. Null-coalescing assignment
//12. Unmanaged constructed types
//13. Stackalloc in nested expressions
//14. Enhancement of interpolated verbatim strings");
